package com.example.calatour.models

data class BreweriesList(
    val breweries: ArrayList<BreweryByCity>
)
